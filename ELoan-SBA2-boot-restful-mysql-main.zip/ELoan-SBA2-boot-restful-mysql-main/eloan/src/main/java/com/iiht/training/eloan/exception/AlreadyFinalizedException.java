package com.iiht.training.eloan.exception;

public class AlreadyFinalizedException extends RuntimeException{

	public AlreadyFinalizedException(String message) {
		super(message);
	}
}
